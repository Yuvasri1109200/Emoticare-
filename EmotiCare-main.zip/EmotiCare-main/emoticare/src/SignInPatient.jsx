import React from 'react';
import SignInForm from './SignInForm';

const SignInPatient = () => {
  return <SignInForm role="Patient" />;
};

export default SignInPatient;
