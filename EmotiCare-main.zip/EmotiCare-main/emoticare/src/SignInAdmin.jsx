import React from 'react';
import SignInForm from './SignInForm';

const SignInAdmin = () => {
  return <SignInForm role="Admin" />;
};

export default SignInAdmin;
